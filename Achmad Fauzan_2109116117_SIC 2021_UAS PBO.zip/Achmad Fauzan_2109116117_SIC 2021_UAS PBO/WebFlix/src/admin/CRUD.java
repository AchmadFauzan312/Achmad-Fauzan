/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import login.KoneksiDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import login.KoneksiDB;
import pelanggan.aaa;

/**
 *
 * @author user
 */
public class CRUD extends KoneksiDB implements interf  {
    @Override
    public void hapus(int id){
        try {
            String sql = "DELETE FROM film WHERE id_film =' " + id + " ' ";
            Connection con =(Connection) KoneksiDB.getKoneksi();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();

            JOptionPane.showInternalMessageDialog(null, "Berhasil Menambahkan");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal Menambahkan" + e.getMessage());
        }
    }

    @Override
    public void tambah(int id, String jd, String gr, String str, String drs) {
        try {
            String sql = "INSERT INTO film VALUES('" + id +"','" + jd +" ',' "+ gr
                    +" ',' "+str +" ',' "+ drs +"')";
            Connection con =(Connection) KoneksiDB.getKoneksi();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            
            JOptionPane.showInternalMessageDialog(null, "Berhasil Menambahkan");
                    
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal Menambahkan" + e.getMessage());
        }
    }
    public void tambah(int id, String gr, String str, String drs) {
        try {
            JOptionPane.showInternalMessageDialog(null, "Lupa Masuk Judul");
                    
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal Menambahkan" + e.getMessage());
        }
    }
    

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin;

/**
 *
 * @author user
 */
public interface interf {
    public void hapus(int id);
    public void tambah(int id, String jd, String gr, String str, String drs);
    
}

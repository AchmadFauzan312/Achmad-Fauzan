/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package admin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import login.KoneksiDB;
import pelanggan.aaa;

/**
 *
 * @author Acer
 */
public final class Crud_film extends javax.swing.JFrame implements aaa{
    CRUD cr = new CRUD();

    public Crud_film() {
        initComponents();
        this.setLocationRelativeTo(null);
        table();

        
    }
    
    
    void search (){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Film");
        tbl.addColumn("Judul");
        tbl.addColumn("Genre");
        tbl.addColumn("Sutradara");
        tbl.addColumn("Durasi");
        
        try {
            String sql = "SELECT * FROM film WHERE judul LIKE '%" + searchFilm.getText() +  "%'";
            Connection con = (Connection) KoneksiDB.getKoneksi();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
                tbl.addRow(new Object[] {
                    rs.getString("id_film"),
                    rs.getString("judul"),
                    rs.getString("genre"),
                    rs.getString("sutradara"),
                    rs.getString("durasi")
                });
                tabelfilm.setModel(tbl);
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    void refresh(){
        idFilm.setText("");
        judul.setText("");
        genre.setText("");
        sutradara.setText("");
        durasi.setText("");
        searchFilm.setText("");
    
    }
    
    
    
    
  
    public void table(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("ID Film");
        tbl.addColumn("Judul");
        tbl.addColumn("Genre");
        tbl.addColumn("Sutradara");
        tbl.addColumn("Durasi");
        
        try {
            Statement st = (Statement) KoneksiDB.getKoneksi().createStatement();
            ResultSet rs =st.executeQuery("SELECT * FROM film ");
            
            while(rs.next()){
                tbl.addRow(new Object[] {
                rs.getString("id_film"),
                rs.getString("judul"),
                rs.getString("genre"),
                rs.getString("sutradara"),
                rs.getString("durasi")
                
                });
                tabelfilm.setModel(tbl);
            }

            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Koneksi Database gagal" + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jCheckBox1 = new javax.swing.JCheckBox();
        jRadioButtonMenuItem1 = new javax.swing.JRadioButtonMenuItem();
        jRadioButtonMenuItem2 = new javax.swing.JRadioButtonMenuItem();
        jRadioButtonMenuItem3 = new javax.swing.JRadioButtonMenuItem();
        jPanel1 = new javax.swing.JPanel();
        tambahFilm = new javax.swing.JButton();
        ubahFilm = new javax.swing.JButton();
        hapusFilm = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        judul = new javax.swing.JTextField();
        sutradara = new javax.swing.JTextField();
        durasi = new javax.swing.JTextField();
        refresh = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelfilm = new javax.swing.JTable();
        genre = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        idFilm = new javax.swing.JTextField();
        search = new javax.swing.JButton();
        searchFilm = new javax.swing.JTextField();

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jCheckBox1.setText("jCheckBox1");

        jRadioButtonMenuItem1.setSelected(true);
        jRadioButtonMenuItem1.setText("jRadioButtonMenuItem1");

        jRadioButtonMenuItem2.setSelected(true);
        jRadioButtonMenuItem2.setText("jRadioButtonMenuItem2");

        jRadioButtonMenuItem3.setSelected(true);
        jRadioButtonMenuItem3.setText("jRadioButtonMenuItem3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));
        jPanel1.setMinimumSize(new java.awt.Dimension(200, 200));
        jPanel1.setPreferredSize(new java.awt.Dimension(500, 302));

        tambahFilm.setText("Tambah ");
        tambahFilm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tambahFilmMouseClicked(evt);
            }
        });
        tambahFilm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahFilmActionPerformed(evt);
            }
        });

        ubahFilm.setText("Ubah");
        ubahFilm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ubahFilmMouseClicked(evt);
            }
        });
        ubahFilm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ubahFilmActionPerformed(evt);
            }
        });

        hapusFilm.setText("Hapus");
        hapusFilm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hapusFilmMouseClicked(evt);
            }
        });
        hapusFilm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusFilmActionPerformed(evt);
            }
        });

        jButton5.setText("Kembali");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("Judul");

        jLabel2.setBackground(new java.awt.Color(0, 0, 102));
        jLabel2.setText("Genre");

        jLabel3.setBackground(new java.awt.Color(0, 0, 102));
        jLabel3.setText("Sutradara");

        jLabel4.setBackground(new java.awt.Color(0, 0, 102));
        jLabel4.setText("Durasi");

        durasi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                durasiActionPerformed(evt);
            }
        });

        refresh.setText("Refresh");
        refresh.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                refreshMouseClicked(evt);
            }
        });
        refresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshActionPerformed(evt);
            }
        });

        tabelfilm.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID FIlm", "Judul", "Genre", "Sutradara", "Durasi"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tabelfilm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelfilmMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabelfilm);

        genre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                genreActionPerformed(evt);
            }
        });

        jLabel5.setBackground(new java.awt.Color(0, 0, 102));
        jLabel5.setText("ID Film");

        idFilm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idFilmActionPerformed(evt);
            }
        });

        search.setText("Search");
        search.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchMouseClicked(evt);
            }
        });
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });

        searchFilm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchFilmActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(81, 81, 81))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 81, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addComponent(tambahFilm, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(ubahFilm, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31)
                        .addComponent(hapusFilm, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(refresh, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(60, 60, 60))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(69, 69, 69)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(idFilm, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                            .addComponent(judul, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(durasi)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(59, 59, 59)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(genre, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                            .addComponent(sutradara))))
                .addGap(113, 113, 113)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(searchFilm)
                    .addComponent(search, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(81, 81, 81))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton5)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(idFilm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(12, 12, 12)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(judul, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(genre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(sutradara, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(durasi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(search)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(searchFilm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tambahFilm, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ubahFilm)
                    .addComponent(hapusFilm)
                    .addComponent(refresh))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 594, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 533, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void hapusFilmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusFilmActionPerformed

        
    }//GEN-LAST:event_hapusFilmActionPerformed

    private void durasiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_durasiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_durasiActionPerformed

    private void tambahFilmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahFilmActionPerformed
        
    }//GEN-LAST:event_tambahFilmActionPerformed

    private void ubahFilmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ubahFilmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ubahFilmActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        dispose();
        halaman_admin ha =new halaman_admin();
        ha.setVisible(true);
        ha.pack();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_refreshActionPerformed

    private void genreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_genreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_genreActionPerformed

    private void tambahFilmMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tambahFilmMouseClicked
        
        int id = Integer.parseInt(idFilm.getText());
        String jd = judul.getText();
        String gr = genre.getText();
        String str = sutradara.getText();
        String drs = durasi.getText();
        if (jd .isEmpty()){
            cr.tambah(id, gr, str, drs);
        }else{
            cr.tambah(id, jd, gr, str, drs);
        }
        
        
//        try {
//            String sql = "INSERT INTO film VALUES('" + a +"','" + judul.getText() +" ',' "+genre.getText()
//                    +" ',' "+sutradara.getText() +" ',' "+ durasi.getText() +"')";
//            Connection con =(Connection) KoneksiDB.getKoneksi();
//            PreparedStatement pst = con.prepareStatement(sql);
//            pst.execute();
//            
//            JOptionPane.showInternalMessageDialog(null, "Berhasil Menambahkan");
//                    
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, "Gagal Menambahkan" + e.getMessage());
//        }
    }//GEN-LAST:event_tambahFilmMouseClicked

    private void idFilmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idFilmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idFilmActionPerformed

    private void refreshMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_refreshMouseClicked
        try {
            String sql ="SELECT * FROM film WHERE id_film = ' " + idFilm.getText() + " ' ";
            Connection con = (Connection) KoneksiDB.getKoneksi();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        table();
        refresh();
    }//GEN-LAST:event_refreshMouseClicked

    private void ubahFilmMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ubahFilmMouseClicked
        
        try {
            String sql = "UPDATE film SET id_film=' " + idFilm.getText() + " ',judul = ' " + judul.getText()
                    + " ',genre = ' " + genre.getText() + " ',sutradara = ' " + sutradara.getText() + " ',durasi =' " + durasi.getText() + " 'WHERE id_film=' " + idFilm.getText() + " ' ";
                    
            Connection con = (Connection) KoneksiDB.getKoneksi();
            PreparedStatement pst = con.prepareStatement(sql);  
            pst.execute();
            JOptionPane.showMessageDialog(null, "Berhasil megubah film");
        } catch (Exception e) {
        }
    }//GEN-LAST:event_ubahFilmMouseClicked

    private void tabelfilmMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelfilmMouseClicked
        int baris = tabelfilm.rowAtPoint(evt.getPoint());
        String id_film = tabelfilm.getValueAt(baris, 0).toString();
        idFilm.setText(id_film);
        String judul_film = tabelfilm.getValueAt(baris, 1).toString();
        judul.setText(judul_film);
        String genre_film = tabelfilm.getValueAt(baris, 2).toString();
        genre.setText(genre_film);
        String sutradara_film = tabelfilm.getValueAt(baris, 3).toString();
        sutradara.setText(sutradara_film);
        String durasi_film = tabelfilm.getValueAt(baris, 4).toString();
        durasi.setText(durasi_film);
        
    }//GEN-LAST:event_tabelfilmMouseClicked

    private void hapusFilmMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hapusFilmMouseClicked

        int id = Integer.parseInt(idFilm.getText());
        
        cr.hapus(id);
        try {
            String sql = "DELETE FROM film WHERE id_film =' " + idFilm.getText() + " ' ";
            
            Connection con = (Connection) KoneksiDB.getKoneksi();
            PreparedStatement pst = con.prepareStatement(sql);  
            pst.execute();
            JOptionPane.showMessageDialog(null, "Berhasil menghapus film");
        } catch (Exception e) {
        }
    }//GEN-LAST:event_hapusFilmMouseClicked

    private void searchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchMouseClicked
//        cari();
       
    
    }//GEN-LAST:event_searchMouseClicked

    private void searchFilmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchFilmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchFilmActionPerformed

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
       search();
    }//GEN-LAST:event_searchActionPerformed
   
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Crud_film().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JTextField durasi;
    private javax.swing.JTextField genre;
    private javax.swing.JButton hapusFilm;
    private javax.swing.JTextField idFilm;
    private javax.swing.JButton jButton5;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem1;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem2;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField judul;
    private javax.swing.JButton refresh;
    private javax.swing.JButton search;
    private javax.swing.JTextField searchFilm;
    private javax.swing.JTextField sutradara;
    private javax.swing.JTable tabelfilm;
    private javax.swing.JButton tambahFilm;
    private javax.swing.JButton ubahFilm;
    // End of variables declaration//GEN-END:variables

    @Override
    public void hallo() {
       System.out.println("hallo");
       
    }
}
